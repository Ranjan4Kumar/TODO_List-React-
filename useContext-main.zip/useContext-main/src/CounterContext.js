import { createContext } from "react";

export const CounterContext = createContext(null);

