import React from 'react'

function Menu() {
  return (
    <h1>This is Menu page</h1>
  )
}

export default Menu